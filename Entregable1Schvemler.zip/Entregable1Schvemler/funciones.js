let cantidad_ingredientes=0;
let margen_ganancia=0;
let ingredientes=[]
let nombre_producto="";
let precio_final=0;
let suma=0;
function iniciar()
{
   nombre_producto= prompt(
      "bienvenido a la calculadora de precios para pastelerìa. Ingrese el nombre del producto que desea realizar"
      );
   if(nombre_producto){
      if(nombre_producto.length>0)
      {
         ingresar_margen_ganancia();
      }
      else{
         iniciar();
      }
   }
}
function ingresar_margen_ganancia(argument) {
   margen_ganancia= prompt("ingrese el margen de ganancia esperado");
   if(parseInt(margen_ganancia)>0){
      ingresar_cantidad();
   }else{
      ingresar_margen_ganancia();
   }
}

function ingresar_cantidad(argument) {
  cantidad_ingredientes= prompt("ingrese la cantidad de ingredientes que lleva")
  if(cantidad_ingredientes>0){
      agregar_ingredientes();
   }else{
      ingresar_cantidad();
   }
}

function agregar_ingredientes(argument)
{
   for(x=1;x<=cantidad_ingredientes;x++)
   {
      let ingrediente_individual=[];
      let nombre_ingrediente = prompt("ingrese el nombre del ingrediente N° "+x);
      let precio_ingrediente = prompt("ingrese el precio");
      ingrediente_individual.push(nombre_ingrediente);
      ingrediente_individual.push(precio_ingrediente);
      ingredientes.push(ingrediente_individual);
   }
   calcularResultados();
   console.log(ingredientes);
   console.log(ingredientes[0][1]);
}

function calcularResultados(argument) {
   suma=0;
   precio_final=0;
   for(x=0;x<cantidad_ingredientes;x++){
      suma=suma+ parseFloat(ingredientes[x][1]);
      console.log(suma);
   }

   let porcentaje=(margen_ganancia/100)+1;
   precio_final=suma*porcentaje;
   mensajeFinal();
}
function mensajeFinal(argument) {
    alert( "Para el producto "+ 
      nombre_producto+ 
      "\n\n" +
      "Son necesarios "+
      cantidad_ingredientes+
      " ingredientes " +
      "\n\n" +
       "El costo de producción total es: $" +
      suma +
       "\n\n" +
      "Se espera tener un margen de ganancia de " +
       margen_ganancia +
      "%" +
      "\n\n" +
       "El precio final esperado será de $" +
        precio_final );

    let respuesta = confirm("¿Deseas calcular el costo de producción de otro producto?");
    if (respuesta) {
        iniciar();
    } 
}